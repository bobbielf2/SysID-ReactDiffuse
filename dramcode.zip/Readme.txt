Some example matlab code to generate MCMC chains using DRAM, Delayed
Rejection Adaptive Metropolis algorithm.

See http://www.helsinki.fi/~mjlaine/dram/ for details.
